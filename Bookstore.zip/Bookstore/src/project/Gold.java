
package project;


public class Gold extends Status{
    private static final String status = "Gold";
    /**
     * Effects: updates the customer status to silver if points are less than 1000
     * @param c 
     */
    @Override
    public void update(Customer c) {
        int points = c.getPoints();
        if(points < 1000)
            c.setStatus(new Silver());
    }

    @Override
    public String getStatus() {
        return status;
    }
    
}
