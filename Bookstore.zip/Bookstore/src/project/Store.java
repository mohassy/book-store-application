
package project;
import java.io.BufferedReader;
import java.util.ArrayList;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class Store {
    private ArrayList<Book> books;
    private ArrayList<User> users;
    private User user;
    
    public Store(){
        books = new ArrayList<Book>();
        users = new ArrayList<User>();
        createBooks();
        createUsers();
    }
    
    public User getUser() {
        return user;
    }


    public ArrayList<Book> getBooks() {
        return books;
    }

    public ArrayList<User> getUsers() {
        return users;
    }
    /**
     * Effects: takes a name and password, if the user is on the file, returns true, else false
     * @param name
     * @param password
     * @return 
     */
    public boolean login(String name, String password){
        if(user != null){
            return true; // already logged into the system
        }
        for(User u: users){
            if(u.getName().equals(name) && u.getPassword().equals(password)){
                user = u;
                return true;
            }
        }
        return false;
    }
    /**
     * Effects: logs out user and sets instance variables to null
     */
    public void logout(){
        user.logout();
        books = null;
        users = null;
        user = null;
    }
    
    /**
     * Effects: buys books that are selected and calculates total cost
     * @return 
     */
    public double buyBooks(){
        double totalPrice = 0;
        ArrayList<Book> removeList = new ArrayList<Book>();
        
        for(Book b: books){
            if(b.isSelected() && user instanceof Customer){
                ((Customer)user).buyBook(b);
                totalPrice += b.getPrice();
                //remove book from file
                ((Owner)(users.get(0))).removeBook(b.getName());
                removeList.add(b);
            }
        }
        
        for(Book b : removeList){
            books.remove(b);
        }
        return totalPrice;
    }
    
    /**
     * Effects: buys books that are selected with points if points are sufficient, else buys books normal and calculates total 
     * @return 
     */
        public double buyBooksWP(){
        double totalPrice = 0;
        ArrayList<Book> removeList = new ArrayList<Book>();
        
        for(Book b: books){
            int bPrice = (int)b.getPrice();
            int points = ((Customer)user).getPoints();
            if(b.isSelected() && user instanceof Customer)
                if(points >= (bPrice * 100)){
                    ((Customer)user).buyBookWP(b);
                    // remove books from array and file
                    ((Owner)(users.get(0))).removeBook(b.getName());
                    removeList.add(b);
                }else if( points < (bPrice * 100)){
                    
                    int discounted = b.getPrice() - points/100;
                    ((Customer)user).setPoints(0);
                    totalPrice =+ discounted;
                    ((Customer)user).setPoints(discounted*10);
                    
                    
                    //totalPrice += b.getPrice();
                    //((Customer)user).buyBook(b); // discounted //points = 0;
                    // remove books from array and file
                    ((Owner)(users.get(0))).removeBook(b.getName());
                    removeList.add(b);
                }   
        }
        
        for(Book b : removeList){
                books.remove(b);
        }
        
        return totalPrice;
    }
    /**
     * Effects: adds books to file and books arrayList if user is owner
     * @param name
     * @param price 
     */
    public void addBook(String name, String price){
        if(user instanceof Owner){
            Book b = new Book(name,(int)Double.parseDouble(price));
            books.add(b);
            ((Owner)user).addBook(name, price);
        }
    }
    /**
     * Effects: removes books from file and books arrayList if they are selected by owner
     */
    public void removeBooks(){
        // if book is selected remove book
        ArrayList<Book> removeList = new ArrayList<Book>();
        if(user instanceof Owner){
            for(Book b: books){
                if(b.isSelected() && user instanceof Owner){
                    ((Owner)user).removeBook(b.getName());
                    removeList.add(b);
                }
            }
            for(Book b : removeList){
                books.remove(b);
            }
        }
    }
    /**
     * Effects: adds customer to file and customer arrayList if user is owner
     * @param name
     * @param password 
     */
    public void addCustomer(String name, String password){
        // add customer to array list and file
        if(user instanceof Owner){
            Customer c = new Customer(name, password, 0);
            users.add(c);
            ((Owner)user).addCustomer(name, password);
        }
    }
    /**
     * Effects: removes customers from file and customers arrayList if they are selected by owner
     */
    public void removeCustomers(){
        //removes customer if customer is selected
        ArrayList<Customer> removeList = new ArrayList<Customer>();
        if(user instanceof Owner){
            for(int i=1; i<users.size(); i++){
                if(((Customer)(users.get(i))).isSelected()){
                        ((Owner)user).removeCustomer(((Customer)(users.get(i))).getName());
                        removeList.add((Customer)(users.get(i)));
                    } 
            }
            for(Customer c : removeList){
                users.remove(c);
            }
        }
           
        
    }
    /**
     * Effects: helper method that creates books from file and adds them to books arrayList
     */
    private void createBooks(){
        String filepath = "books.txt";
        Book book;
        int position = 0;
        int price;
        
        String currentLine;
        String data[];
        try{
            FileReader fr = new FileReader(filepath);
            BufferedReader br = new BufferedReader(fr);
            
            while((currentLine = br.readLine()) != null){
                data = currentLine.split(",");
                
                price = (int)Double.parseDouble(data[position+1]);
                book = new Book(data[position], price);
                books.add(book);
            }
            
            br.close();
            fr.close();
            
        }catch(IOException e){
            System.out.println(e.toString());
        }
    }
    /**
     * Effects: helper method that creates users from file and adds them to customers arrayList
     */
    private void createUsers(){
        String filepath = "users.txt";
        
        int position = 0;
        int i = 0;
        int points;
        User user;
        
        String currentLine;
        String data[];
        try{
            File file = new File(filepath);
            FileReader fr = new FileReader(file);
            BufferedReader br = new BufferedReader(fr);
            while((currentLine = br.readLine()) != null){
                data = currentLine.split(",");
                points = (int)Double.parseDouble(data[position+2]);
                if(i == 0){
                    user = Owner.getInstance(data[position], data[position+1]);
                    i++;
                }else{
                    user = new Customer(data[position], data[position+1], points);
                }
                users.add(user);
            }
            fr.close();
            br.close();
        }catch(IOException e){
            System.out.println(e.toString());
        }
    }
    
}
