
package project;


import java.util.ArrayList;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.VBox;
import javafx.scene.layout.HBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

public class Project extends Application {
    private Store bookStore; //global bookStore variable
    
    /**
     * login screen
     * @param primaryStage 
     */
    @Override
    public void start(Stage primaryStage) {
        
        bookStore = new Store();
        //Nodes 
        Label Welcome = new Label("Welcome to the BookStore App");
        Welcome.getStyleClass().add("title");
        Label Username = new Label("Username: ");
        Label Password = new Label("Password: ");
        TextField UsernameTxt = new TextField();
        PasswordField PasswordTxt = new PasswordField();
        Button btn = new Button();
        
        
        //Login button 
        btn.setText("Login");
        
        /**
         * Setup of login scene
         */
        // panes
        
        FlowPane pane = new FlowPane();
        VBox vbox = new VBox(10);
        HBox hbox = new HBox(10);
        VBox vbox1 = new VBox(25);
        VBox vbox2 = new VBox(20);
        
        //add labels and textfields to vbox1
        vbox1.getChildren().add(Username);
        vbox1.getChildren().add(Password);
        
        //add labels, textfield and bottons to vbox2
        vbox2.getChildren().add(UsernameTxt);
        vbox2.getChildren().add(PasswordTxt);
        vbox2.getChildren().add(btn);
        
        //add vboxes to hbox
        hbox.getChildren().add(vbox1);
        hbox.getChildren().add(vbox2);
        
        //add welcome to vbox
        vbox.getChildren().add(Welcome);
        //add hbox to vbox
        vbox.getChildren().add(hbox);
        //add vbox to pane
        pane.getChildren().add(vbox);
        pane.setAlignment(Pos.CENTER);
        
        //setup Scene
        Scene loginScene = new Scene(pane, 500, 250);
        loginScene.getStylesheets().add("style/stylesheet.css");
        primaryStage.setTitle("Book Store");
        primaryStage.setScene(loginScene);
        primaryStage.centerOnScreen();
        primaryStage.show();
        
        
        /**
         * Event Handlers
         */
        
        btn.setOnAction((ActionEvent event) -> {
            boolean login;
            login = bookStore.login(UsernameTxt.getText(), PasswordTxt.getText());
            if (login){
                if(bookStore.getUser() instanceof Owner){
                    //change to owner start scene
                    ownerStart(primaryStage);
                }else if(bookStore.getUser() instanceof Customer){
                    //change to customer start scene
                    customerStart(primaryStage);
                }
                
            }else{
                PasswordTxt.clear();
            }
        });
        //enter on password field
        PasswordTxt.setOnAction((ActionEvent event) -> btn.fire());
        UsernameTxt.setOnAction((ActionEvent event) -> btn.fire());
        primaryStage.setOnCloseRequest((WindowEvent e) -> {
            if(bookStore.login("", ""))
                bookStore.logout();
        });
        
    }
    /**
     * owner start screen
     * @param primaryStage 
     */
    private void ownerStart(Stage primaryStage){
        /**
         * Setup of owner-start scene
         */
        //nodes
        Button booksBtn = new Button("Books");
        Button customersBtn = new Button("Customers");
        Button logoutBtn = new Button("Logout");
        booksBtn.setPrefWidth(200);
        booksBtn.setPrefHeight(50);
        customersBtn.setPrefWidth(200);
        customersBtn.setPrefHeight(50);
        logoutBtn.setPrefWidth(200);
        logoutBtn.setPrefHeight(50);
        //panes
        FlowPane pane = new FlowPane();
        VBox vbox = new VBox(20);
        
        vbox.getChildren().add(booksBtn);
        vbox.getChildren().add(customersBtn);
        vbox.getChildren().add(logoutBtn);
        
        
        pane.getChildren().add(vbox);
        pane.setAlignment(Pos.CENTER);
        
        Scene OwnerStart = new Scene(pane, 500, 250);
        OwnerStart.getStylesheets().add("/style/stylesheet.css");
        primaryStage.setTitle("Welcome Owner");
        primaryStage.setScene(OwnerStart);
        primaryStage.centerOnScreen();
        primaryStage.show();
        
        /**
         * setup event handlers for the three buttons
         */
        
        booksBtn.addEventHandler(ActionEvent.ACTION, (ActionEvent event)->
                ownerBook(primaryStage));
        
        customersBtn.addEventHandler(ActionEvent.ACTION, (ActionEvent event) ->
                ownerCustomer(primaryStage));
        
        logoutBtn.addEventHandler(ActionEvent.ACTION, (ActionEvent event) -> {
            bookStore.logout();
            start(primaryStage);
        });
    }
    /**
     * owner books screen
     * @param primaryStage 
     */
    private void ownerBook(Stage primaryStage){
        //setup owner book scene
        //table
        TableView<Book> bookTable = new TableView<>();
        bookTable.setEditable(true);
        //name column
        TableColumn<Book, String> nameColumn= new TableColumn("Book Name");
        nameColumn.setCellValueFactory(
               new PropertyValueFactory<>("name"));
        nameColumn.setMinWidth(300);
        //price column
        TableColumn<Book, String> priceColumn= new TableColumn("Book Price");
        priceColumn.setCellValueFactory(
                new PropertyValueFactory<>("string"));
        priceColumn.setMinWidth(75);
        //select column
        TableColumn selectCol = new TableColumn();
        selectCol.setCellValueFactory(
                new PropertyValueFactory<>("select"));
        selectCol.setMinWidth(10);
        
        ObservableList<Book> books = books();
        bookTable.getColumns().add(nameColumn);
        bookTable.getColumns().add(priceColumn);
        bookTable.getColumns().add(selectCol);
        bookTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        
        for(Book b : books)
            bookTable.getItems().add(b);
        
        //scene setup
        Label nameLabel = new Label("Name:");
        Label priceLabel = new Label("Price:");
        TextField nameT = new TextField();
        TextField priceT = new TextField();
        Button addBtn = new Button("[Add]");
        Button backBtn = new Button("Back");
        Button deleteBtn = new Button("Delete");
        HBox hbox = new HBox();
        hbox.getChildren().addAll(backBtn, deleteBtn);
        hbox.setPadding(new Insets(20, 20, 20, 20));
        hbox.setSpacing(100);
        hbox.setAlignment(Pos.CENTER);
        HBox hbox1 = new HBox();
        hbox1.getChildren().addAll(nameLabel, nameT, priceLabel, priceT, addBtn);
        hbox1.setAlignment(Pos.CENTER);
        hbox1.setPadding(new Insets(20, 20, 20, 20));
        hbox1.setSpacing(20);
        FlowPane flowPane = new FlowPane();
        VBox vbox = new VBox();
        vbox.getChildren().addAll(bookTable, hbox1, hbox);
        vbox.setPadding(new Insets(20, 20, 20, 20));
        vbox.setSpacing(10);
        flowPane.getChildren().add(vbox);
        flowPane.setAlignment(Pos.CENTER);
        
        Scene scene = new Scene(flowPane, 650, 650);
        scene.getStylesheets().add("/style/stylesheet.css");
        primaryStage.setTitle("Owner Books");
        primaryStage.setScene(scene);
        primaryStage.centerOnScreen();
        
        /**
         * setup handlers
        */
        addBtn.setOnAction((ActionEvent e)->{
            String bookName = nameT.getText();
            String price = priceT.getText();
            if(!bookName.equals("") && !price.equals("")){
                Book b = new Book(bookName, (int)Double.parseDouble(price));
                bookTable.getItems().add(b);
                bookStore.addBook(bookName, price);
                books.add(b);
                nameT.clear();
                priceT.clear();
            }
            ownerBook(primaryStage);
        });
        priceT.setOnAction((ActionEvent event) -> addBtn.fire());
        backBtn.setOnAction((ActionEvent event)->{
            ownerStart(primaryStage);
        });
        
        
        deleteBtn.setOnAction((ActionEvent event) -> {
            ArrayList<Book> removeList = new ArrayList<Book>();
                for(Book b : books){
                    if(b.isSelected()){
                        bookTable.getItems().remove(b);
                        b.select();
                        removeList.add(b);
                    }
                }
                for(Book b : removeList){
                    books.remove(b);
                }
                bookStore.removeBooks();
        });
        
    }
    /**
     * owner customer screen
     * @param primaryStage 
     */
    private void ownerCustomer(Stage primaryStage){
        //setup owner customer scene
        TableView<Customer> customerTable = new TableView<>();
        customerTable.setEditable(true);
        
        //name col
        TableColumn<Customer, String> nameColumn= new TableColumn("User Name");
        nameColumn.setCellValueFactory(
            new PropertyValueFactory<>("name"));
        nameColumn.setMinWidth(100);
        //password col
        TableColumn<Customer, String> passwordColumn= new TableColumn("Password");
        passwordColumn.setCellValueFactory(
            new PropertyValueFactory<>("password"));
        passwordColumn.setMinWidth(100);
        //points col
        TableColumn<Customer, Integer> pointsColumn= new TableColumn("Points");
        pointsColumn.setCellValueFactory(
            new PropertyValueFactory<>("points"));
        pointsColumn.setMinWidth(75);
        //select col
        TableColumn selectCol = new TableColumn();
        selectCol.setCellValueFactory(
                new PropertyValueFactory<>("select"));
        selectCol.setMinWidth(10);
        
        ObservableList<Customer> customers = customers();

        customerTable.getColumns().add(nameColumn);
        customerTable.getColumns().add(passwordColumn);
        customerTable.getColumns().add(pointsColumn);
        customerTable.getColumns().add(selectCol);
        customerTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        
        for(Customer c : customers)
            customerTable.getItems().add(c);
        
        //scene setup
        Label nameLabel = new Label("Name:");
        Label passwordLabel = new Label("Password:");
        TextField nameT = new TextField();
        TextField passwordT = new TextField();
        Button addBtn = new Button("[Add]");
        Button backBtn = new Button("Back");
        Button deleteBtn = new Button("Delete");
        HBox hbox = new HBox();
        hbox.getChildren().addAll(backBtn, deleteBtn);
        hbox.setPadding(new Insets(20, 20, 20, 20));
        hbox.setSpacing(100);
        hbox.setAlignment(Pos.CENTER);
        HBox hbox1 = new HBox();
        hbox1.getChildren().addAll(nameLabel, nameT, passwordLabel, passwordT, addBtn);
        hbox1.setAlignment(Pos.CENTER);
        hbox1.setPadding(new Insets(20, 20, 20, 20));
        hbox1.setSpacing(20);
        FlowPane flowPane = new FlowPane();
        VBox vbox = new VBox();
        vbox.getChildren().addAll(customerTable, hbox1, hbox);
        vbox.setPadding(new Insets(20, 20, 20, 20));
        vbox.setSpacing(10);
        flowPane.getChildren().add(vbox);
        flowPane.setAlignment(Pos.CENTER);
        
        
        Scene scene = new Scene(flowPane, 650, 650);
        scene.getStylesheets().add("/style/stylesheet.css");
        primaryStage.setTitle("Owner Customers");
        primaryStage.setScene(scene);
        primaryStage.centerOnScreen();
        /**
         * setup handlers
         */
        addBtn.setOnAction((ActionEvent event)->{
            String name = nameT.getText();
            String password = passwordT.getText();
            if(!name.equals("") && !password.equals("")){
                Customer c = new Customer(name, password, 0);
                bookStore.addCustomer(name, password);
                customers.add(c);
                customerTable.getItems().add(c);
                nameT.clear();
                passwordT.clear();
            }
            ownerCustomer(primaryStage);
        });
        passwordT.setOnAction((ActionEvent event) -> addBtn.fire());
        backBtn.setOnAction((ActionEvent event)->
                ownerStart(primaryStage));
        
        
        deleteBtn.setOnAction((ActionEvent event) -> {
            ArrayList<Customer> removeList = new ArrayList<Customer>();
                for(Customer c : customers){
                    if(c.isSelected()){
                        customerTable.getItems().remove(c);
                        c.select();
                        removeList.add(c);
                    }
                }
                for(Customer c : removeList){
                    customers.remove(c);
                }
                bookStore.removeCustomers();
        });
    }
    /**
     * customer start screen
     * @param primaryStage 
     */
    private void customerStart(Stage primaryStage){
        //setup customer start screen
        
        //table
        TableView<Book> bookTable = new TableView<>();
        bookTable.setEditable(true);
        //name column
        TableColumn<Book, String> nameColumn= new TableColumn("Book Name");
        nameColumn.setCellValueFactory(
               new PropertyValueFactory<>("name"));
        nameColumn.setMinWidth(300);
        //price column
        TableColumn<Book, String> priceColumn= new TableColumn("Book Price");
        //
        priceColumn.setCellValueFactory(
                new PropertyValueFactory<>("string"));
        priceColumn.setMinWidth(75);
        //select column
        TableColumn selectCol = new TableColumn();
        selectCol.setCellValueFactory(
                new PropertyValueFactory<>("select"));
        selectCol.setMinWidth(10);
        
        ObservableList<Book> books = books();
        bookTable.getColumns().add(nameColumn);
        bookTable.getColumns().add(priceColumn);
        bookTable.getColumns().add(selectCol);
        bookTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        
        for(Book b : books)
            bookTable.getItems().add(b);
        
        //scene setup
        Text text = new Text("Welcome "+bookStore.getUser().getName()
                                    +". You have "+((Customer)bookStore.getUser()).getPoints()
                                    +" Points. Your Status is " +((Customer)bookStore.getUser()).getStatus());
        text.getStyleClass().add("title");
        Button buyBtn = new Button("[Buy]");
        Button buyWPBtn = new Button("[Redeem points and Buy]");
        Button logoutBtn = new Button("[Logout]");
        HBox hbox = new HBox();
        hbox.getChildren().addAll(logoutBtn, buyBtn, buyWPBtn);
        hbox.setPadding(new Insets(20, 20, 20, 20));
        hbox.setSpacing(100);
        hbox.setAlignment(Pos.CENTER);
        HBox hbox1 = new HBox();
        hbox1.getChildren().add(text);
        hbox1.setAlignment(Pos.CENTER);
        hbox1.setPadding(new Insets(20, 20, 20, 20));
        hbox1.setSpacing(20);
        FlowPane flowPane = new FlowPane();
        VBox vbox = new VBox();
        vbox.getChildren().addAll(hbox1, bookTable, hbox);
        vbox.setPadding(new Insets(20, 20, 20, 20));
        vbox.setSpacing(10);
        flowPane.getChildren().add(vbox);
        flowPane.setAlignment(Pos.CENTER);
        
        
        Scene scene = new Scene(flowPane, 650, 650);
        scene.getStylesheets().add("/style/stylesheet.css");
        primaryStage.setTitle("Customer Book Store");
        primaryStage.setScene(scene);
        primaryStage.centerOnScreen();
        
        /**
         * setup handlers
        */
        
        buyBtn.setOnAction((ActionEvent event) -> {
            for(Book b : books){
                    if(b.isSelected()){
                        bookTable.getItems().remove(b);
                        b.select();
                    }
                }
                double total = bookStore.buyBooks();
                customerCost(primaryStage, total);
        });
        
        buyWPBtn.setOnAction((ActionEvent event) -> {
            for(Book b : books){
                    if(b.isSelected()){
                        bookTable.getItems().remove(b);
                        b.select();
                    }
                }
                double total = bookStore.buyBooksWP();
                customerCost(primaryStage, total);
        });
        
        logoutBtn.setOnAction((ActionEvent event) -> {
            bookStore.logout();
            start(primaryStage);
        });
        
            
    }
    /**
     * customer cost screen
     * @param primaryStage
     * @param total 
     */
    private void customerCost(Stage primaryStage, double total){
        /**
         * setup scene
         */
        VBox vbox = new VBox(20);
        vbox.setAlignment(Pos.CENTER);
        HBox hb1 = new HBox(20);
        hb1.setAlignment(Pos.CENTER);
        HBox hb2 = new HBox(20);
        hb2.setAlignment(Pos.CENTER);
        HBox hb3 = new HBox(20);
        hb3.setAlignment(Pos.CENTER);
        Text txt1 = new Text("Total Cost: $" + (int)total );
        Text txt2 = new Text("Points: " + ((Customer)(bookStore.getUser())).getPoints() +
                               "\t\tStatus: " + ((Customer)(bookStore.getUser())).getStatus());
        Button logoutBtn = new Button("[Logout]");
        txt1.getStyleClass().add("title");
        txt2.getStyleClass().add("title");
        FlowPane pane = new FlowPane();
        pane.setPadding(new Insets(20, 20, 20, 20));
        pane.setAlignment(Pos.CENTER);
        hb1.getChildren().add(txt1);
        hb2.getChildren().add(txt2);
        hb3.getChildren().add(logoutBtn);
        vbox.getChildren().addAll(hb1, hb2, hb3);
        pane.getChildren().add(vbox);
        
        Scene scene = new Scene(pane, 500, 500);
        scene.getStylesheets().add("/style/stylesheet.css");
        primaryStage.setScene(scene);
        primaryStage.setTitle("Transaction Cost");
        primaryStage.centerOnScreen();
        
        
        /**
         * setup handler
         */
        
        logoutBtn.setOnAction((ActionEvent event) -> {
            bookStore.logout();
            start(primaryStage);
        });
    }
    
    private ObservableList<Book> books(){
        ObservableList<Book> books = FXCollections.observableArrayList();
        //adds all books from store to the books list
        for(Book b: bookStore.getBooks()){
            books.add(b);
        }
        return books;
    }
    
    private ObservableList<Customer> customers(){
        ObservableList<Customer> customers = FXCollections.observableArrayList();
        
        for(int i=1; i<(bookStore.getUsers()).size(); i++){
            customers.add((Customer)((bookStore.getUsers()).get(i)));
        }
        return customers;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
   
}
