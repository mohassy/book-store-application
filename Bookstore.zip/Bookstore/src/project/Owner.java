
package project;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class Owner extends User{
    private static Owner instance;
    
    private Owner(String name, String password){
        super(name, password);
    }
    /**
     * Effects: Always returns the same instance of Owner class
     * @param name
     * @param password
     * @return 
     */
    public static Owner getInstance(String name, String password){
        if(instance == null)
            instance = new Owner(name, password);
        return instance;
    }
    /**
     * Effects: adds book to file 
     * @param book
     * @param price 
     */
    public void addBook(String book, String price){
        String filepath = "books.txt";
        File file = new File(filepath);
        String myData = book + "," + price + "\n";
        try{
            FileWriter  fw = new FileWriter(file, true);
            BufferedWriter bw = new BufferedWriter(fw);
            bw.write(myData);
            bw.close();
            fw.close();
        }catch(IOException e){
            System.out.println(e.toString());
        }
    }
    /**
     * Effects: removes book from file
     * @param deleteBook 
     */
    public void removeBook(String deleteBook){
        int position = 0;
        String filepath = "books.txt";
        String tempFile = "temp.txt";
        File oldFile = new File(filepath);
        File newFile = new File(tempFile);
           
        String currentLine;
        String data[];
        try{
            FileWriter  fw = new FileWriter(tempFile, true);
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter pw = new PrintWriter(bw);
            
            FileReader fr = new FileReader(new File(filepath));
            BufferedReader br = new BufferedReader(fr);
               
            while((currentLine = br.readLine()) != null){
                data = currentLine.split(",");
                if(!((data[position]).equals(deleteBook))){
                    pw.println(currentLine);
                }
            }

            pw.flush();
            pw.close();
            br.close();
            fr.close();
            bw.close();
            fw.close();
            
            oldFile.delete();
            File dump = new File(filepath);
            newFile.renameTo(dump);
        }catch(IOException e){
            System.out.println(e.toString());
        }
    }
    /**
     * Effects: adds customer to file
     * @param name
     * @param password 
     */
    public void addCustomer(String name, String password){
        String filepath = "users.txt";
        File file = new File(filepath);
        String myData = name + "," + password + "," + "0\n"; 
        try{
            FileWriter  fw = new FileWriter(file, true);
            BufferedWriter bw = new BufferedWriter(fw);
            bw.write(myData);
            bw.close();
            fw.close();
        }catch(IOException e){
            System.out.println(e.toString());
        }
    }
    /**
     * Effects: removes customer from file
     * @param deleteUser 
     */
    public void removeCustomer(String deleteUser){
        int position = 0;
        String filepath = "users.txt";
        String tempFile = "temp.txt";
        File oldFile = new File(filepath);
        File newFile = new File(tempFile);
        
        String currentLine;
        String data[];
           
        try{
            FileWriter  fw = new FileWriter(tempFile, true);
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter pw = new PrintWriter(bw);
            
            
            FileReader fr = new FileReader(new File(filepath));
            BufferedReader br = new BufferedReader(fr);
            
            while((currentLine = br.readLine()) != null){
                data = currentLine.split(",");
                if(!((data[position]).equals(deleteUser))){
                    pw.println(currentLine);
                }
            }

            pw.flush();
            pw.close();
            bw.close();
            fw.close();
            br.close();
            fr.close();
            
            oldFile.delete();
            File dump = new File(filepath);
            newFile.renameTo(dump);
        }catch(IOException e){
            System.out.println(e.toString());
        }
    }
    
    @Override
    public void logout(){
        //do nothing
    }
}
