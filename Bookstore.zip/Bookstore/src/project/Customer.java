
package project;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import javafx.scene.control.CheckBox;

public class Customer extends User {
    private int points;
    private Status status;
    private CheckBox select;
    
    public Customer(String name, String password, int points){
        super(name, password);
        this.points = points;
        select = new CheckBox();
        select.setSelected(false);
        status = new Silver();
        status.update(this);
    }
    
    public CheckBox getSelect() {
        return select;
    }

    public void select() {
        select.setSelected(true);
    }
    
    public boolean isSelected(){
        return select.isSelected();
    }

    public int getPoints() {
        return points;
    }

    public void setPoints(int points) {
        this.points = points;
        status.update(this);
    }

    public String getStatus() {
        return status.getStatus();
    }

    public void setStatus(Status s) {
        status = s;
    }
    /**
     * Effects: calculates the points of the customer when they purchase a book
     * @param b 
     */
    public void buyBook(Book b){
        int price = (int) (b.getPrice());
        setPoints(getPoints() + (price * 10));
    }
    /**
     * Effects: calculates the points of the customer when they buy book with points
     * @param b 
     */
    
    public void buyBookWP(Book b){
        int price = (int) (b.getPrice());
        setPoints(getPoints() - (price * 100));
    }
    /**
     * Saves the customers points to file document
     * @param editUser
     * @param newPoints 
     */
    private void saveCustomer(String editUser, String newPoints){
        int position = 0;
        String filepath = "users.txt";
        String tempFile = "temp.txt";
        File oldFile = new File(filepath);
        File newFile = new File(tempFile);
        
        String currentLine;
        String data[];
        
        try{
            FileWriter  fw = new FileWriter(tempFile, true);
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter pw = new PrintWriter(bw);
            File file = new File(filepath);
            FileReader fr = new FileReader(file);
            BufferedReader br = new BufferedReader(fr);
            
            
            while((currentLine = br.readLine()) != null){
                data = currentLine.split(",");
                if(data[position].equals(editUser)){
                    pw.println(data[position] + "," + data[position+1] + "," + newPoints);
                }else{
                    pw.println(currentLine);
                }
            }
            pw.flush();
            pw.close();
            bw.close();
            fw.close();
            br.close();
            fr.close();
            
            oldFile.delete();
            File dump = new File(filepath);
            newFile.renameTo(dump);
        }catch(IOException e){
            System.out.println(e.toString());
        }
    }
    /**
     * Effect: saves the customer's points to file using saveCustomer helper method
     */
    @Override
    public void logout(){
        String strPoints = "" + points;
        saveCustomer(this.getName(), strPoints);
    }
    
}
