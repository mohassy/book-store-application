
package project;

public class Silver extends Status{
    private static final String status = "Silver";
    /**
     * Effects: updates customer status to gold if points >= 1000
     * @param c 
     */
    public void update(Customer c){
        int points = c.getPoints();
        if(points >= 1000)
            c.setStatus(new Gold());
    }
    
    @Override
    public String getStatus(){
        return status;
    }
}
