
package project;

public abstract class Status {
    public abstract void update(Customer c);
    public abstract String getStatus();
}
