
package project;

import javafx.scene.control.CheckBox;

public class Book {
    private String name;
    private int price;
    private CheckBox select;


    public Book(String name, int price){
        this.name = name;
        this.price = price;
        select = new CheckBox();
        select.setSelected(false);
        
    }
    
    public CheckBox getSelect() {
        return select;
    }

    public void select() {
        select.setSelected(true);
    }
    
    public boolean isSelected(){
        return select.isSelected();
    }
    
    public String getName() {
        return name;
    }

    public int getPrice() {
        return price;
    }
    
    public String getString() {
        return "$ " + price;
    }
}
